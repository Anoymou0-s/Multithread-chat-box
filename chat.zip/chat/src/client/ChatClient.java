package client;

import java.io.*;
import java.net.Socket;

public class ChatClient {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 12345;

        try (Socket socket = new Socket(host, port);
             BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
             BufferedReader serverInput = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter serverOutput = new PrintWriter(socket.getOutputStream(), true)) {

            System.out.println("Connected to chat server");

            Thread reader = new Thread(() -> {
                String response;
                try {
                    while ((response = serverInput.readLine()) != null) {
                        System.out.println("Server: " + response);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            reader.start();

            String input;
            while ((input = userInput.readLine()) != null) {
                serverOutput.println(input);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
