INSERT INTO users (username) VALUES ('Alice'), ('Bob'), ('Charlie');
